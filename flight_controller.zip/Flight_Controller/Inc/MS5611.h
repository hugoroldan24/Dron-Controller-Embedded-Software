/*
 * MS5611.h
 *
 *  Created on: Jul 24, 2025
 *      Author: 34684
 */

#ifndef MS5611_H_
#define MS5611_H_

#include <stdint.h>

void init_ms5611(void);
int32_t read_preassure(void);

#endif /* MS5611_H_ */
