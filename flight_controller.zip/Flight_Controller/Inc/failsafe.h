/*
 * failsafe.h
 *
 *  Created on: Aug 19, 2025
 *      Author: 34684
 */

#ifndef FAILSAFE_H_
#define FAILSAFE_H_

void failsafe_execute_landing(void);


#endif /* FAILSAFE_H_ */
