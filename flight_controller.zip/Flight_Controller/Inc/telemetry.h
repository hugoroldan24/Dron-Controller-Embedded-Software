/*
 * telemetry.h
 *
 *  Created on: Aug 5, 2025
 *      Author: 34684
 */

#ifndef TELEMETRY_H_
#define TELEMETRY_H_



void send_telemetry(Telemetry_t data);


#endif /* TELEMETRY_H_ */
