/*
 * pwm.h
 *
 *  Created on: Jul 27, 2025
 *      Author: 34684
 */

#ifndef PWM_H_
#define PWM_H_

void pwm_init();
void start_PWM();

#endif /* PWM_H_ */
