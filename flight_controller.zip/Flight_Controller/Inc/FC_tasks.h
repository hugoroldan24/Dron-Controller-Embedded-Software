/*
 * FC_tasks.h
 *
 *  Created on: Sep 3, 2025
 *      Author: 34684
 */

#ifndef FC_TASKS_H_
#define FC_TASKS_H_


void createTasks(void);

#endif /* FC_TASKS_H_ */
