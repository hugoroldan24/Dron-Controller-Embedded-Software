/*
 * delay.h
 *
 *  Created on: Jul 26, 2025
 *      Author: 34684
 */

#ifndef DELAY_H_
#define DELAY_H_

void init_delay_timer(void);
void delay_ms(uint32_t ms);
void delay_us(uint32_t us);


#endif /* DELAY_H_ */
