/*
 * telemetry.c
 *
 *  Created on: Aug 5, 2025
 *      Author: 34684
 */

/* This timer will be the trigger source of our ADC (every 200 ms) */

#include "battery_lecture.h"
#include "MS5611.h"
#include "uart.h"
#include "math.h"
#include "const.h"

#include <stdint.h>

static void ProcessBatteryAndAltitude(uint16_t raw_battery, int32_t raw_preassure, uint8_t telemetry_data[]);

void send_telemetry(Telemetry_t data)
{

	static uint8_t telemetry_data[4];

	ProcessBatteryAndAltitude(data.battery_level,data.preassure,telemetry_data);

	uart_send_dma(telemetry_data,TELEM_FRAME_LEN);
}

/* Esta función se encarga de encontrar la cantidad de batería y la altura relativa */

static void ProcessBatteryAndAltitude(uint16_t raw_battery, int32_t raw_preassure, uint8_t telemetry_data[])
{
	static uint8_t first;
	static int32_t Pref; /*Esta es la presión medida al encender el drón, se usará como referencia para calcular la altura*/

	float battery_voltage = (((float)raw_battery / ADC_MAX_VALUE)*VREF*DIVIDER_FACTOR)/3; /* Divide by 3 to get the voltage per cell */

	if(battery_voltage <= BATTERY_MIN_V)
	{
		/* Si esto ocurre , activar algoritmo de seguridad */
	}
	if(!first){
		Pref = raw_preassure;
		first = 1;
	}
	/* Esta formula te convierte la presión a altura en metros */
	float height = 44330.0f * (1.0f - powf(raw_preassure / Pref,0.1903f));

	/* Separamos la parte entera y decimal y las guardamos de forma contigua en el vector */

	telemetry_data[0]  =  (uint8_t)battery_voltage;
	telemetry_data[1]  =  (uint8_t)((battery_voltage-telemetry_data[0])*10);

	telemetry_data[2]  =  (uint8_t)height;
	telemetry_data[3]  =  (uint8_t)((height-telemetry_data[2])*10);

}


