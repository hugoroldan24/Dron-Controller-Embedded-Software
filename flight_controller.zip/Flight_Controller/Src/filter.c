/*
 * filter.c
 *
 *  Created on: Jul 30, 2025
 *      Author: 34684
 */


/* Este fichero sirve para fusionar los valores del giroscopio y acelerometro obtenidos */
#include <math.h>
#include "stm32f411xe.h"
#include <stdint.h>
#include "const.h"
#include "dron_structs.h"

#include "util.h"
/* Función que aplica un filtro que combina acc + gyr, ha de devolver el ángulo de pitch y roll + yawn relativ*/
/* Recibe un buffer con los valores de acc.
 * buf[0] => acc_x
 * buf[1] => acc_y
 * buf[2] => acc_z
 * buf[3] => gyr_x
 * buf[4] => gyr_y
 * buf[5] => gyr_z
 */



void computeAttitudeFromIMU(float imu_data[6], Attitude_t* attitude,uint32_t* lastcall)
{

	/* Como tenemos que utilizar el valor anterior de los diferentes angulos, hacemos una variable estatica local */
	static float roll;
	static float pitch;

	float dt = get_time_elapsed(lastcall);

	// La conversión de signo a uint, en caso de ser negativa la resta hace que se haga modulo

    // Calculas los ángulos del acelerómetro

	float acc_pitch = atan2f(-imu_data[0], sqrtf(imu_data[1]*imu_data[1] + imu_data[2]*imu_data[2])) * RAD_TO_DEG;
	float acc_roll  = atan2f(imu_data[1], imu_data[2]) * RAD_TO_DEG;          // en grados

    // Integras giroscopio para predecir nuevos ángulos
	// dt es el tiempo que transcurre entre cada llamada a la función
	// CNT gives us the time in us that went by */

	roll += imu_data[3] * dt;
	pitch += imu_data[4] * dt;

	/* Como trabajamos con la velocidad angular, no necesitamos integrar y por tanto no necesitamos que la variable sea estática */
	float yaw = imu_data[5];

    // Aplicar filtro complementario para roll y pitch
	roll = ALPHA * roll + (1 - ALPHA) * acc_roll;
    pitch = ALPHA * pitch + (1 - ALPHA) * acc_pitch;

    attitude->roll = roll;
    attitude->pitch = pitch;
    attitude->yaw_rate = yaw;

}
