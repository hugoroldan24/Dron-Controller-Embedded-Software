/*
 * spi.c
 *
 *  Created on: Aug 14, 2025
 *      Author: 34684
 */



/* Pin selection:
 * SCK2  = PB10
 * MOSI2 = PB15
 * MISO2 = PB14
 * SS    = PB8
 *
 */

#include "stm32f411xe.h"
#include "const.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdint.h>

static void spi2_tx_callback(void);
static void spi2_rx_callback(void);
static void SPI_GPIO_Init(void);

static volatile uint8_t *tx_buffer;
static volatile uint32_t tx_size;
static volatile uint32_t tx_index;

static volatile uint8_t *rx_buffer;
static volatile uint32_t rx_size;
static volatile uint32_t rx_index;

static volatile uint32_t temp;

extern TaskHandle_t SENSORS_ID; /* Obtenemos el handle de la tarea que ejecuta el SPI */

static volatile BaseType_t pxHigherPriorityTaskWoken;

static void SPI_GPIO_Init(void)
{
	/* Set PB8 High before setting it as output */
	GPIOB->ODR |= GPIO_ODR_OD8;

	/* Set PB8 as output */
	GPIOB->MODER = (GPIOB->MODER & ~GPIO_MODER_MODER8) | (0x1 << GPIO_MODER_MODER8_Pos);

	/* Set PB10, PB14, PB15 to alternate mode */
	GPIOB->MODER = (GPIOB->MODER & ~GPIO_MODER_MODER10) | (0x2 << GPIO_MODER_MODER10_Pos);
	GPIOB->MODER = (GPIOB->MODER & ~GPIO_MODER_MODER14) | (0x2 << GPIO_MODER_MODER14_Pos);
	GPIOB->MODER = (GPIOB->MODER & ~GPIO_MODER_MODER15) | (0x2 << GPIO_MODER_MODER15_Pos);

	/*Select alternate function	 */
	GPIOB->AFR[1] = ((GPIOB->AFR[1])&~(GPIO_AFRH_AFSEL10)) | (0x5 << GPIO_AFRH_AFSEL10_Pos);
	GPIOB->AFR[1] = ((GPIOB->AFR[1])&~(GPIO_AFRH_AFSEL14)) | (0x5 << GPIO_AFRH_AFSEL14_Pos);
	GPIOB->AFR[1] = ((GPIOB->AFR[1])&~(GPIO_AFRH_AFSEL15)) | (0x5 << GPIO_AFRH_AFSEL15_Pos);
}

void SPI_Init(void)
{
	SPI_GPIO_Init();

	/********CONFIGURE SPI PARAMETERS***********/

	/* Enable clock access to SPI2		     */
	RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;

	/* Set prescaler to 50/4 = 12.5 MHz (20 MHz is the max our preassure sensor can support) */
	SPI2->CR1 = (SPI2->CR1 & ~SPI_CR1_BR) | (0x4 << SPI_CR1_BR_Pos);

	/* Set polarity to mode 3 */
	SPI2->CR1 |= SPI_CR1_CPOL;
	SPI2->CR1 |= SPI_CR1_CPHA;

	/* Set data format to 8 bits */
	SPI2->CR1 &= ~SPI_CR1_DFF;

	/* Send MSB first */
	SPI2->CR1 &= ~SPI_CR1_LSBFIRST;

	/* Activate full-duplex */
	SPI2->CR1 &= ~SPI_CR1_RXONLY;

	/* Configure MCU as the SPI Master */
	SPI2->CR1 |= SPI_CR1_MSTR;

	/* Enable Software Slave Management */
	SPI2->CR1 |= SPI_CR1_SSM;
	SPI2->CR1 |= SPI_CR1_SSI;

	/* Enable Error Interrupt */
	SPI2->CR2 |= SPI_CR2_ERRIE;

	/* Enable SPI2 interrupt */
	NVIC_EnableIRQ(SPI2_IRQn);

	/* Enable SPI */
	SPI2->CR1 |= SPI_CR1_SPE;
}

void SPI_Transmit(uint8_t *data, uint32_t size)
{
	tx_buffer = data;
	tx_size = size;
	tx_index = 0;

	tx_flag = 0;
	SPI2->CR2 |= SPI_CR2_TXEIE; // Habilitar interrupción TXE

	xTaskNotifyWait(0,0,NULL,pdMS_TO_TICKS(1000)); // Si tras 1 s no se ha despertado, se despertará

    while(SPI2->SR & SPI_SR_BSY);  /* Esperar a que el último byte salga del MOSI */

    (void)SPI2->DR;				   /* Vaciamos el buffer de la data dummy enviada por el módulo */

}

void SPI_Receive(uint8_t *data, uint32_t size)
{
	rx_buffer = data;
	rx_size = size;
	rx_index = 0;

	(void)SPI2->DR; /* Vaciamos el buffer por si queda data residual */

	rx_flag = 0;

	SPI2->CR2 |= SPI_CR2_RXNEIE;  /* Enable RXNE interrupt */

	/* Send dummy data to start receiving data */
	SPI2->DR = DUMMY;

	xTaskNotifyWait(0,0,NULL,pdMS_TO_TICKS(1000));

	while(SPI2->SR & SPI_SR_BSY); /* Esperar a que se libere el bus para seguir */
}

static void spi2_tx_callback(void)
{
	/* Quizá es buena idea meter otro if dentro cuando = tx_size para desactivarlo ya y evitar otra ISR */
	if(tx_index < tx_size)
	{
		SPI2->DR = tx_buffer[tx_index++];
	}
	else
	{
		SPI2->CR2 &= ~SPI_CR2_TXEIE; //Desactivamos la ISR de transmisión
		pxHigherPriorityTaskWoken = pdFALSE;
		xTaskNotifyFromISR(SENSORS_ID,0,eNoAction,&pxHigherPriorityTaskWoken); //No action, no hacemos nada sobre el notification value
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
	}
}

static void spi2_rx_callback(void)
{
	rx_buffer[rx_index++] = SPI2->DR;
	if(rx_index < rx_size)
	{
		SPI2->DR = DUMMY;
	}
	else
	{
		SPI2->CR2 &= ~SPI_CR2_RXNEIE; //Desactivamos la ISR de recepción
		pxHigherPriorityTaskWoken = pdFALSE;
		xTaskNotifyFromISR(SENSORS_ID,0,eNoAction,NULL);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);

	}
}

void cs_enable(void){GPIOB->ODR &= ~GPIO_ODR_OD8;}
void cs_disable(void){GPIOB->ODR |= GPIO_ODR_OD8;}


void SPI2_IRQHandler(void)
{
	uint32_t sr =  SPI2->SR;
	uint32_t cr2 = SPI2->CR2;

	/* Check if the flag was pulled and the TXE is enabled */
	if((sr & SPI_SR_TXE) && (cr2 & SPI_CR2_TXEIE))
	{
		spi2_tx_callback();
	}

	if((sr & SPI_SR_RXNE) && (cr2 & SPI_CR2_RXNEIE))
	{
		spi2_rx_callback();
	}

	if(sr & SPI_SR_OVR)
	{
		/* Clear overrun flag */
		temp = SPI2->DR;
		temp = SPI2->SR;
	}
}
