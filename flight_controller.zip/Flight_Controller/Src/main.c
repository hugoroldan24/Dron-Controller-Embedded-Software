#include "stm32f411xe.h"
#include "dron_structs.h"



/* PINES USADOS
 *
 * Battery lecture:
 * PA2
 *
 * MPU6050
 * PA4
 *
 * I2C:
 * PB6 = SCL, PB7 = SDA
 *
 * PWM:
 * PA6, PA7, PB0, PB1
 *
 * SPI:
 * PB8 = CS, PB10 = SCK, PB14 = MISO, PB15 = MOSI
 *
 * UART:
 * PA9 = TX , PA10 = RX
 *
 *
 */
#include "FC_tasks.h"
#include "FreeRTOS.h"
#include "task.h"

int main(void)
{
	Periph_Init();

	createTasks();
	vTaskStartScheduler();

	while(1);

	return 0;
}

/* Función callback que se ejecutará cuando entremos en la tarea IDLE */
void vApplicationIdleHook(void)
{
	__WFI(); //Since by default SLEEPDEEP bit from the Cortex M4 System Control Register is 0, it will send the MCU to SLEEP_NOW mode
}




/* 	mpu_write(PWR_MGMT_1_R,(uint8_t[]){0x09}); // Salir del SLEEP
		status = mpu_read_acc_gyr(buf);
		mpu_write(PWR_MGMT_1_R,(uint8_t[]){0x40 | 0x09}); //Poner SLEEP para parar la conversion mientras debugamos (evitar OFLOW)
		accx = buf[0];
		accy = buf[1];
		accz = buf[2];
		gyrx = buf[3];
		gyry = buf[4];
		gyrz = buf[5];

*/


/*RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
GPIOC->MODER |= (1U << 26);
GPIOC->MODER &= ~(1U << 27);
init_timer5();
uart1_txrx_init();
__enable_irq();

char *string = "Hola buenas ";
while(1)
{
uart_write(USART1,(uint8_t *)string,strlen(string));
delay_ms(5000);
}
 */



/* TESTEO DEL UART */

/*
 * 	uart1_txrx_init();

	uint8_t byte_sent = 0x1F;
	uint8_t byte_read = 0;
	delay_ms(1000);

	while(1)
	{
		uart_write(USART1,&byte_sent,1);
		uart_read_buff(&byte_read,1);
	}
 */

/*
 * SystemClock_Config();
	I2C1_Init();
	uart1_txrx_init();
	init_delay_timer();
	init_mpu6050();
	init_ms5611();

	pwm_init();
	dt_timer_init();
	start_PWM();

	float imu_data[6];
	UserControl_t joystick_data;
	Setpoint_t 	  sp;
	Attitude_t 	  error;
	Attitude_t	  measure;

	PID_Controller_t roll_pid_params;
	PID_Controller_t pitch_pid_params;
	PID_Controller_t yaw_pid_params;

	PID_Outputs_t output;

	uint32_t first = 1;
	uint32_t lastcall = 0;
	float dt;

	while(1){


	get_joystick_data(&joystick_data);
	map_joystick_to_setpoint(joystick_data, &sp);

	mpu_read_acc_gyr(imu_data);
	computeAttitudeFromIMU(imu_data, &measure);

	computePIDError(sp, measure, &error);


	dt = get_time_elapsed(&lastcall,&first);
	output.roll 	= compute_PID(error.roll, dt, &roll_pid_params);
	output.pitch 	= compute_PID(error.pitch, dt, &pitch_pid_params);
	output.yaw_rate = compute_PID(error.yaw_rate, dt, &yaw_pid_params);

	motor_mixer(output,sp.throttle,&ccr);
 */


