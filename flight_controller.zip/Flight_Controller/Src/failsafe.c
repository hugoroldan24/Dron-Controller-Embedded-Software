/*
 * failsafe.c
 *
 *  Created on: Aug 19, 2025
 *      Author: 34684
 */


#include "stm32f411xe.h"
#include "joystick_mapper.h"
#include "const.h"
#include "dron_structs.h"


/* El Problema de usar la altura para ajustar la bajada, es como trabajamos con altura relativa, esto solo nos seriviria si el terreno es plano.
 * Si hay por ejemplo bajada respecto la altura de referencia, si el dron justo entra en failsafe en la bajada, apagará los motores más arriba de la esperado */

/* A parte de esto, cuando implemente RTOS, el hilo encargado de comunicarse con el receptor RF, gestionará que cuando pase un cierto tiempo sin recibir datos (conexion perdida)*/
/* Active la funcion de failsafe */
static void set_hover(void);

void failsafe_execute_landing(void)
{
	/* Antes deberias apagar todo lo que te sobre, mantener lo fundamental para poder bajar */
	/* 1. Poner el dron en hover */
	/* 2. Empezar a disminuir el throttle muy poco a poco */
	/* 3. A la que se detecte que no hay cambio de altura grande, querrá decir que ya estamos en el suelo, apagar motores */
	/* Apagar todos los perifericos y todo */


		/* Por tanto, hasta que no organize todo con el RTOS , esto se lioso hacerlo, pero la idea es:
		 * Input como si estuvieramos en reposo
		 * Poner el throttle tal que en reposo nos mantenemos quietos (encontrarlo experimentalmente)
		 * A traves del error, ver si es tal que nos permite asumir que estamos estables en el aire
		 * Luego empezar a disminuir el throttle poco a poco
		 * Cuando detectemos que el cambio de altura es 0, querrá decir que hemos tocado suelo
		 * Por tanto, apagar TODO (apagar perifericos, matar hilos ...) entrar en modo Standby
		 */

	 /* Para disminuir el throttle deberé en el setpoint ir modificando este throttle cada un cierto tiempo y seguir ejecutando todo (RTOS)*/



}

static void set_hover(void)
{
	/* Haz como si recibieras que los joysticks están en reposo */
	UserControl_t input = { .left_x_axis = JOY_MID,
							.left_y_axis = JOY_MID,
							.right_x_axis = JOY_MID,
							.right_y_axis = JOY_MID
	};

	Setpoint_t setpoint;
	map_joystick_to_setpoint(input, &setpoint);

	/* Piensa que al trabajar con RTOS, no se llamaran las funciones seguidas en el main, estarán repartidas en los distintos hilos */
	/* Principalmente, el calculo del IMU se hará en un hilo aparte */
}
