/*
 * joystick_maper.c
 *
 *  Created on: Aug 1, 2025
 *      Author: 34684
 */
#include "stm32f411xe.h"
#include "const.h"
#include "uart.h"
#include "dron_structs.h"


/* Aquí seguro que metemos cosas de RTOS de waits y tal para el tema de la circular queue*/
void get_joystick_data(UserControl_t* input)
{
	/* Al hacer el protocolo del UART, asumimos que los bytes de start y checksum no los queremos guardar y son propios del protocolo */
	uart1_read_dma(input->axis,FRAME_LEN-1); /* Importante aqui el orden sea el que queremos */
}

/* Aquí hay que decidir que eje se le asigna a cada angulo/throttle */
/* De momento lo haré considerando que:
 * Joystick izquierdo (canal 1 y 2):
Y eje (vertical) → throttle (potencia general, subir/bajar)

X eje (horizontal) → yaw (rotar sobre eje vertical)

Joystick derecho (canal 3 y 4):
Y eje (vertical) → pitch (adelante/atrás)

X eje (horizontal) → roll (izquierda/derecha)
 */

void map_joystick_to_setpoint(UserControl_t input, FlightMessage* setpoint)
{
	/* Aquí aplicar las funciones para mapear */
	/* Le metes el valor del eje del joystick en digital y te devuelve el angulo mapeado */

	setpoint->attitude->roll     =     MAP_JOYSTICK_TO_ANGLE(input.right_x_axis);
	setpoint->attitude->pitch    = 	 MAP_JOYSTICK_TO_ANGLE(input.right_y_axis);
	setpoint->attitude->yaw_rate = 	 MAP_JOYSTICK_TO_YAW(input.left_x_axis);

	/* Este valor ya se usará directamente para el PWM */
	setpoint->throttle =     MAP_JOYSTICK_TO_THROTTLE(input.left_y_axis); /*Mapeamos el throttle considerando los márgenes */
}

