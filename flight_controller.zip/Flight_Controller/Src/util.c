/*
 * util.c
 *
 *  Created on: Aug 5, 2025
 *      Author: 34684
 */


#include "stm32f411xe.h"
#include "const.h"


/* Timer para contar la diferencia de tiempo entre cada llamada de las funciones */
/* Free running timer */
void dt_timer_init()
{
	/* Clock acces to Timer 2 */
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

	/* Set Prescaler, since the prescaler for APB1 bus is 2, the timer clock is twice the bus freq. so it is 100 MHz */
	TIM2->PSC = 2*APB1_CLK_MHZ - 1;  // 100 MHz / (99 +1) = 1 MHz -> 1 tick = 1us

	/* Upcounting */
	TIM2->CR1 &= ~TIM_CR1_DIR;

	/* Start timer */
	TIM2->CR1 |= TIM_CR1_CEN;
}

uint32_t get_time_now_us()
{
	uint32_t now = TIM2->CNT;
	return now;
}

float get_time_elapsed(uint32_t* lastcall)
{
	uint32_t now = TIM2->CNT;
	uint32_t diff = now - *lastcall; /* Ojo módulo */
	*lastcall = now;
	float dt = US_TO_S(diff);
	return dt;
}

void constrain(float* value, float low, float high)
{
	if(*value<low)
	{
		*value = low;
	}
	else if(*value>high)
	{
		*value = high;
	}
}

void eliminate_first(uint8_t arr[], uint8_t len) {
    for (uint8_t i = 1; i < len; i++) {
        arr[i - 1] = arr[i];
    }
}

