/*
 * pwm.c
 *
 *  Created on: Jul 27, 2025
 *      Author: 34684
 */

#include "stm32f411xe.h"
#include "const.h"
#include "dron_structs.h"

/* Pins used:
 * PA6: 	TIM3_CH1
 * PA7:		TIM3_CH2
 * PB0:		TIM3_CH3
 * PB1: 	TIM3_CH3
 */

static void update_timer_init(void);
static void GPIO_PWM_Init(void);


volatile static uint16_t ccr1,ccr2,ccr3,ccr4;
extern PWM_Outputs_t ccr;

static void update_timer_init()
{
	/* Clock acces to Timer 3 */
	RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

	/* Set Prescaler, since the prescaler for APB1 bus is 2, the timer clock is twice the bus freq. so it is 100 MHz */
	TIM4->PSC = 2*APB1_CLK_MHZ - 1;  // 100 MHz / (99 +1) = 1 MHz -> 1 tick = 1us

	/* Upcounting */
	TIM4->CR1 &= ~TIM_CR1_DIR;

	/* Set URS so that only counter overflow triggers interrupt ( so that when we do a reset setting UG bit, we don't trigger any interrupt */
	TIM4->CR1 |= TIM_CR1_URS;

	TIM4->ARR = UPDATE_REG_PERIOD - 1;

	/* Force the update from ARR (we restart the counter from 0) Wont trigger interrupt*/
	TIM4->EGR |= TIM_EGR_UG;

	/* Clear pending interrupt just in case */
	TIM4->SR &= ~TIM_SR_UIF;

	/* Enable event interrupt */
	TIM4->DIER |= TIM_DIER_UIE;
	NVIC_EnableIRQ(TIM4_IRQn);    // Activa la interrupción de TIM4 en el NVIC

}

static void GPIO_PWM_Init()
{
	/*------------------PIN CONFIGURATION------------------------*/

	/* Set PORT_A pins to alternate function mode */
	GPIOA->MODER = (GPIOA->MODER & ~GPIO_MODER_MODER6) | (2 << GPIO_MODER_MODER6_Pos);
	GPIOA->MODER = (GPIOA->MODER & ~GPIO_MODER_MODER7) | (2 << GPIO_MODER_MODER7_Pos);

	/* Set PORT_B pins to alternate function mode */
	GPIOB->MODER = (GPIOB->MODER & ~GPIO_MODER_MODER0) | (2 << GPIO_MODER_MODER0_Pos);
	GPIOB->MODER = (GPIOB->MODER & ~GPIO_MODER_MODER1) | (2 << GPIO_MODER_MODER1_Pos);

	/* Configure PORT_A alternate pin function to AF02 */
	GPIOA->AFR[0] = ((GPIOA->AFR[0])&~(GPIO_AFRL_AFSEL6)) | (2 << GPIO_AFRL_AFSEL6_Pos);
	GPIOA->AFR[0] = ((GPIOA->AFR[0])&~(GPIO_AFRL_AFSEL7)) | (2 << GPIO_AFRL_AFSEL7_Pos);

	/* Configure PORT_B alternate pin function to AF02 */
	GPIOB->AFR[0] = ((GPIOB->AFR[0])&~(GPIO_AFRL_AFSEL0)) | (2 << GPIO_AFRL_AFSEL0_Pos);
	GPIOB->AFR[0] = ((GPIOB->AFR[0])&~(GPIO_AFRL_AFSEL1)) | (2 << GPIO_AFRL_AFSEL1_Pos);
}

void pwm_init()
{
	GPIO_PWM_Init();

	/*--------------------PWM CONFIGURATION--------------------------*/
	/* Enable clock acces to TIM3 */
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

	/* Set Prescaler, since the prescaler for APB1 bus is 2, the timer clock is twice the bus freq. so it is 100 MHz */
	TIM3->PSC = 2*APB1_CLK_MHZ - 1;  // 100 MHz / (99 +1) = 1 MHz -> 1 tick = 1us

	/* Upcounting */
	TIM3->CR1 &= ~TIM_CR1_DIR;

	/* Select PWM mode 1 for CH1 and CH2 */
	TIM3->CCMR1 = (TIM3->CCMR1 & ~TIM_CCMR1_OC1M) | (6 << TIM_CCMR1_OC1M_Pos);
	TIM3->CCMR1 = (TIM3->CCMR1 & ~TIM_CCMR1_OC2M) | (6 << TIM_CCMR1_OC2M_Pos);

	/* Select PWM mode 1 for CH3 and CH4 */
	TIM3->CCMR2 = (TIM3->CCMR2 & ~TIM_CCMR2_OC3M) | (6 << TIM_CCMR2_OC3M_Pos);
	TIM3->CCMR2 = (TIM3->CCMR2 & ~TIM_CCMR2_OC4M) | (6 << TIM_CCMR2_OC4M_Pos);

	/* Enable the corresponding preload register for CH1 and CH2 (esto es para que al cambiar el valor del CCR (donde se compara) no se ponga automaticaamentey se espere a un evento*/
	TIM3->CCMR1 |= (TIM_CCMR1_OC1PE | TIM_CCMR1_OC2PE);

	/* Enable the corresponding preload register for CH3 and CH4 */
	TIM3->CCMR2 |= (TIM_CCMR2_OC3PE | TIM_CCMR2_OC4PE);

	/* Since the PWM period won't change, ARR won't be dinamically modified so we dont need to set ARPE bit */

	/*------------SET REGISTER VALUES----------------*/

	/* This sets the PWM period, take account each tick equals to 1 us so if ESC_PWM_PERIOD = 50, the period would be 50 us */
	TIM3->ARR = ESC_PWM_PERIOD -1 ;

	/* Those are the values where when CNT matches CCRx value, the OCx bit will be cleared, creating the PWM pulse */
	TIM3->CCR1 = (uint16_t)IDLE_PULSE;
	TIM3->CCR2 = (uint16_t)IDLE_PULSE;
	TIM3->CCR3 = (uint16_t)IDLE_PULSE;
	TIM3->CCR4 = (uint16_t)IDLE_PULSE;

	/* Al poner valores en CRR y tal, no se actualizan automaticamente, se quedan en los registros sombra. Hay que forzar una actualización  */
	TIM3->EGR |= TIM_EGR_UG;

	/* Enable channels and set channel output polarity (since the default polarity is active high, we dont do anything)  */
	TIM3->CCER |= (TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E | TIM_CCER_CC4E);

	update_timer_init();
}

/* We will use TIM4 (16 bit) to create a time that when reaches ARR, updates CCR register values. */

void start_PWM(void)
{
	/* Start PWM generation */
	TIM3->CR1 |= TIM_CR1_CEN;

	/* Start update timer   */
	TIM4->CR1 |= TIM_CR1_CEN;
}

void TIM4_IRQHandler(void)
{
	if(TIM4->SR & TIM_SR_UIF)
	{
		TIM4->SR &= ~TIM_SR_UIF;
		TIM3->CCR1 = ccr.motor1_pwm;
		TIM3->CCR2 = ccr.motor2_pwm;
		TIM3->CCR3 = ccr.motor3_pwm;
		TIM3->CCR4 = ccr.motor4_pwm;
	}
}


