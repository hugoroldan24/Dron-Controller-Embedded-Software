/*
 * system_clock.c
 *
 *  Created on: Jul 22, 2025
 *      Author: 34684
 */

#include "stm32f411xe.h"
#include <stdint.h>

static void SystemClock_Init(void);
static void ClockAcces_Init(void);
static void FPU_Enable(void);
static void NVIC_Prio_Config(void);

/* This function is called in the Reset_Handler */
void SystemInit()
{
	SystemClock_Init();
	ClockAcces_Init();
	FPU_Enable();
	NVIC_Prio_Config();
}

static void SystemClock_Init(void)
{
	/* Habilitamos HSE */
	RCC->CR |= RCC_CR_HSEON;

	while (!(RCC->CR & RCC_CR_HSERDY));

	/* Set 3 WS (working at 100 MHz and 3.3V supply voltage) */
	FLASH->ACR |= FLASH_ACR_LATENCY_3WS;

	/* Seleccionamos HSE como entrada del PLL principal */
	RCC->PLLCFGR = (RCC->PLLCFGR &~RCC_PLLCFGR_PLLSRC) | RCC_PLLCFGR_PLLSRC_HSE;

	/* Configurar el prescaler de la entrada del PLL , respetando los rangos VCO_IN [1 a 2 MHz] */
	RCC->PLLCFGR = ((RCC->PLLCFGR) &~(RCC_PLLCFGR_PLLM)) | RCC_PLLCFGR_PLLM_2; /* PLLM = 4 (para obtener VCO =8/4 = 2 MHz (reduce el jitter) */

	/* Configurar el prescaler para controlar la multiplicación de VCO, ha de quedar entre 100 y 423 MHz */
	RCC->PLLCFGR = (RCC->PLLCFGR &~RCC_PLLCFGR_PLLN) | (100 << RCC_PLLCFGR_PLLN_Pos); /* PLNN = 100 para que nos quede VCO_out = 100 * 2 = 200 MHz */

	/* Configurar el prescaler para controlar la salida del PLL, que será la entrada del sistema */
	RCC->PLLCFGR = (RCC->PLLCFGR &~RCC_PLLCFGR_PLLP)  | (0 << RCC_PLLCFGR_PLLP_Pos); /* PLLP = 2 para que nos quede PLL_out = 200 /2 = 100 MHz */

	/* Configurar el prescaler del bus APB1 (50 MHz) */
	RCC->CFGR = (RCC->CFGR &~RCC_CFGR_PPRE1)  | RCC_CFGR_PPRE1_2;

	/* Activamos el PLL principal */
	RCC->CR |= RCC_CR_PLLON;

	/* Esperamos a que nos confirmen que el PLL está estable */
	while(!(RCC->CR & RCC_CR_PLLRDY));

	/* Seleccionamos PLL como SYSCLK */
	RCC->CFGR = (RCC->CFGR &~RCC_CFGR_SW) | RCC_CFGR_SW_PLL;

	/* Esperamos a que el MCU nos confirme que se ha seleccionado el PLL como SYSCLK */
	while(((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL));
}

/* Funcion que da acceso a los relojes de los puertos GPIO que usamos */
static void ClockAcces_Init(void)
{
	/* Enable clock access to GPIOA */
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

	/* Enable clock access to GPIOB */
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

	/* Enable clock access to GPIOC */
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;

}

static void NVIC_Prio_Config(void)
{
	NVIC_SetPriorityGrouping(0x3); // 4 bits preemption, 0 subpriority (daria igual si es 0 1 2 o 3)

	NVIC_SetPriority(TIM4_IRQn   ,1); // ISR de PWM más prioritaria
	NVIC_SetPriority(I2C1_EV_IRQn,2);
	NVIC_SetPriority(USART1_IRQn ,2);
	NVIC_SetPrioritu(EXTI4_IRQn  ,2);
	NVIC_SetPriority(SPI2_IRQn   ,3);
	NVIC_SetPriority(ADC_IRQn    ,3);
}

/* Función que da permisos al coprocesador de coma flotante CP10 y CP11 */
static void FPU_Enable(void)
{
	/* El registro CPACR gestiona los permisos para los coprocesadores, si ponemos 11, le damos Full Acces */
	SCB->CPACR = (0xF << 20);
	__DSB(); /* Barrera de sincronización de datos, se asegura que todas las operaciones de memoria y registros se completen antes de continuar */
	__ISB(); /* Barrera de sincronización de instrucciones, asegura que la CPU lea la nueva configuración antes de ejecutar la siguiente instrucción */
}
