/*
 * MS5611.c
 *
 *  Created on: Jul 24, 2025
 *      Author: 34684
 */

#include <stdint.h>
#include "spi.h"
#include "const.h"
#include "delay.h"


static void ms5611_read_calibration(void);       // lee y almacena C1–C6
static int32_t ms5611_calc_pressure(uint32_t D1, uint32_t D2);

static uint16_t get_prom_coeff(uint8_t maddr);
static uint32_t get_raw_data(uint8_t command);

static uint16_t C1, C2, C3, C4, C5;


void init_ms5611()
{
	SPI_Init();
    delay_ms(5); /* Some delay to do a proper restart */
	cs_enable();
	SPI_Transmit((uint8_t[]){RESET},1);
	cs_disable();

	delay_ms(3); /* 3ms delay after reset */

	/* Read calibration data */
	ms5611_read_calibration();
}

int32_t read_preassure(void)
{
	/* Get preassure 4096 bit precision raw data */
	uint32_t D1 = get_raw_data(CMD_CONVERT_D1_OSR_4096);

	/* Get temperature 4096 bit precision raw data */
	uint32_t D2 = get_raw_data(CMD_CONVERT_D2_OSR_4096);

	return ms5611_calc_pressure(D1,D2);
}

static int32_t ms5611_calc_pressure(uint32_t D1, uint32_t D2)
{
	int32_t dT   =  (int32_t)D2 - ((int32_t)C5 << 8);							// Difference between actual and reference temperature
	int64_t OFF  =  ((int64_t)C2 << 16) + (((int64_t)C4 * (int64_t)dT) >> 7);		// Offset at actual temperature
	int64_t SENS =  ((int64_t)C1 << 15) + (((int64_t)C3 * (int64_t)dT) >> 8);						// Sensitivity at actual temperature
	int64_t temp =  (((int64_t)D1 * SENS) >> 21) - OFF;
	int32_t P 	 = 	(int32_t)(temp >> 15);									// Actual preassure (after compensation)

	return P;
}

static void ms5611_read_calibration()
{
	/* Read calibration data */
	C1 =  get_prom_coeff(PROM_C1_SENS_ADDR);	// Pressure sensitivity coefficient
	C2 =  get_prom_coeff(PROM_C2_OFF_ADDR);		// Pressure offset coefficient
	C3 =  get_prom_coeff(PROM_C3_TCS_ADDR);		// Temperature coefficient of pressure sensitivity
	C4 =  get_prom_coeff(PROM_C4_TCO_ADDR);		// Temperature coefficient of pressure offset
	C5 =  get_prom_coeff(PROM_C5_TREF_ADDR);	// Reference temperature
}


static uint32_t get_raw_data(uint8_t command)
{
	uint8_t buf[3];

	/* Start conversion */
	cs_enable();
	SPI_Transmit((uint8_t[]){command},1);
	cs_disable();

	/* Wait for conversion completed */
	delay_ms(9);

	cs_enable();
	SPI_Transmit((uint8_t[]){ADC_READ},1); // Enviamos el comando de leer el ADC
	SPI_Receive(buf,3);					   // Obtenemos la info
	cs_disable();

	/* Assemble 24-bit result from 3 bytes */
	uint32_t D = (((uint32_t)buf[0] << 16) | ((uint32_t)buf[1] << 8) | (uint32_t)buf[2]);
	D &= 0xFFFFFF;
	return D;
}

static uint16_t get_prom_coeff(uint8_t maddr)
{
	uint8_t buf[2];
	/* Send command to read PROM */

	cs_enable();
	SPI_Transmit((uint8_t[]){maddr},1);
	SPI_Receive(buf,2);
	cs_disable();

	return (((uint16_t)buf[0] << 8) | (uint16_t)buf[1]);
}
