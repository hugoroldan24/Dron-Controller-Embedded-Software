/*
 * mpu6050.c
 *
 *  Created on: Jul 23, 2025
 *      Author: 34684
 */

#include "stm32f411xe.h"
#include "const.h"
#include "i2c.h"
#include "delay.h"
#include <stdint.h>


static volatile uint8_t data_ready;
static uint16_t			fifo_count;

void mpu_read (uint8_t reg_addr,uint8_t* reg)
{
	i2c1_perform_action(READ, MPU_I2C_ADDR, reg_addr, 1, reg);
}

void mpu_write (uint8_t reg_addr, uint8_t* value)
{
	i2c1_perform_action(WRITE, MPU_I2C_ADDR, reg_addr, 1, value);
}

/* Revisar esto del MSB del FIFO y tal*/
int mpu_read_acc_gyr (float buf[6])
{
	uint8_t raw_buf[NUM_BYTES];
	uint8_t count_buf[2];
	while(!data_ready); /* Esperar a que haya datos válidos (no quiere decir que ya esten puestos en el FIFO) */
	data_ready = 0;

	uint8_t temp;
	/* We clear the DATA_RDY_INT flag */
	mpu_read(INT_STATUS_R,&temp);

	/* Check if OFLOW occurred */
	if(temp & FIFO_OFLOW_INT)
	{
		mpu_write(USER_CTRL_R, (uint8_t[]){0x00}); /* Disable FIFO */

		delay_ms(1);

		mpu_write(USER_CTRL_R,(uint8_t[]){0x04});

		delay_ms(1);	/* Wait reset */

		mpu_write(USER_CTRL_R,(uint8_t[]){0x40}); // FIFO_EN

		return -1; /* Overflow occurred  */
	}

	/* Wait until we have data in FIFO */
	while(1)
	{
		/* Burst read both FIFO_COUNT_H and _L registers to know how many bytes are in the FIFO */
		i2c1_perform_action(READ, MPU_I2C_ADDR, FIFO_COUNT_H_R, 2, count_buf);

		fifo_count = ((uint16_t)count_buf[0] << 8) | (uint16_t)count_buf[1];

		if(fifo_count >= NUM_BYTES) break;

		delay_us(FIFO_POLL_US);
	}

	/* Obtain the acc + gyr data and put it into the buffer */
	i2c1_perform_action(READ, MPU_I2C_ADDR, FIFO_R_W_R, NUM_BYTES, raw_buf);

	/* Usamos la sensibilidad para pasar de data raw a flotante */
	float scale_factor;

	for(uint8_t i=0,j = 0;i<NUM_BYTES;i+=2, j++)
	{	/* Primeros 6 bytes son de ACC y los 6 ultimos de GYR */
		if(i<(NUM_BYTES/2)){
			scale_factor = ACC_SCALE_FACTOR;
		}
		else{
			scale_factor = GYR_SCALE_FACTOR;
		}
		/* The first byte in the buff is the MSB and the second the LSB */
		/* Revisar esto del MSB del FIFO y tal*/
		int16_t val = (int16_t)(((uint16_t)raw_buf[i] << 8) | (uint16_t)raw_buf[i+1]);
		buf[j] = (float)val/(scale_factor);
	}
	return 1;

}

void init_mpu6050()
{
	/* Disable global interrupts */
	__disable_irq();
	I2C1_Init();

	/* Enable clock acces to SYSCFGEN (needed to use EXTI) */
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

	/* Configure PA4 as input */
	GPIOA->MODER = (GPIOA->MODER &~GPIO_MODER_MODER4) | (0 << GPIO_MODER_MODER4_Pos);

	/* Set PA4 with pull-down */
	GPIOA->PUPDR = (GPIOA->PUPDR &~GPIO_PUPDR_PUPD4) | (2 << GPIO_PUPDR_PUPD4_Pos);

	/* Select PORTA for EXTI4 */
	SYSCFG->EXTICR[1] = (SYSCFG->EXTICR[1] &~SYSCFG_EXTICR2_EXTI4)  | (0 << SYSCFG_EXTICR2_EXTI4_Pos);

	/* Unmask EXTI4 */
	EXTI->IMR |= EXTI_IMR_MR4;

	/* Select rising edge trigger */
	EXTI->RTSR |= EXTI_RTSR_TR4;

	/* Enable NVIC */
	NVIC_EnableIRQ(EXTI4_IRQn);

	/* Enable global interrupts */
	__enable_irq();

	// Resetear el dispositivo
	mpu_write(PWR_MGMT_1_R,(uint8_t[]){0x80});

	delay_ms(100); // Esperar tras el reset

	// Resetear accelerometro y giroscopio
	mpu_write(SIGNAL_PATH_RESET_R,(uint8_t[]){0x06});

	delay_ms(100);  //Esperar

	//  Salir del modo de suspensión, usar el PLL del gyro X como clock source y desactivar el sensor de temperatura
	mpu_write(PWR_MGMT_1_R,(uint8_t[]){0x09});

	// Configurar filtros (DLPF) y Sample Rate
	mpu_write(CONFIG_R,(uint8_t[]){DLPF_CFG});

	/* Si Gyr Output Rate = 1 kHz (filtro activado) , Sample Rate = Gyr Output Rate / (1 + SMPLRT_DIV_R) = 1 kHz*/
	mpu_write(SMPLRT_DIV_R,(uint8_t[]){SMPLRT_DIV});

	// Configurar rango del acelerómetro y giroscopio
	mpu_write(ACCEL_CONFIG_R,(uint8_t[]){AFS_SEL});
	mpu_write(GYRO_CONFIG_R,(uint8_t[]){FS_SEL});

	// Resetear FIFO para eliminar datos antiguos

	mpu_write(USER_CTRL_R,(uint8_t[]){0x04});

	delay_ms(1);	/* Wait reset */

	mpu_write(FIFO_EN_R,(uint8_t[]){0x78});	/* Configurar los bytes que meteremos en el FIFO */

	mpu_write(USER_CTRL_R,(uint8_t[]){0x40}); // FIFO_EN

	// Configuramos interrupción como activa alta y push pull
	mpu_write(INT_PIN_CFG_R,(uint8_t[]){0x00});

	// Habilitar interrupción de "data ready"
	mpu_write(INT_ENABLE_R,(uint8_t[]){DATA_RDY_EN});

}

/* Esta ISR te dice que se han escrito los registros de los sensores, no que el FIFO tenga ya los 12 bytes */
void EXTI4_IRQHandler()
{
	EXTI->PR = EXTI_PR_PR4;
	data_ready = 1;
}
