/*
 * motor_mixer.c
 *
 *
 *  Created on: Aug 4, 2025
 *      Author: 34684
 */

#include "const.h"
#include "util.h"
#include "dron_structs.h"


/*ccr_values son ya los valores especificos a colocar en los registros CCR , osea el ancho del pulso */
void motor_mixer(PID_Outputs_t pid_outputs, float throttle, PWM_Outputs_t* ccr)
{
	/* Aquí hacer lo de juntar, para esto hay que considerar la polaridad de los motores y tal */
	/* Voy a tener que estudiar más a fondo todo esto, no me acaba de convener */

	/* El throttle no vamos a permitir que sea de 1000 a 2000 para dejar sitio para las correciones */

	float pwm1 = (throttle + pid_outputs.pitch + pid_outputs.roll - pid_outputs.yaw_rate);
	float pwm2 = (throttle + pid_outputs.pitch - pid_outputs.roll + pid_outputs.yaw_rate);
	float pwm3 = (throttle - pid_outputs.pitch - pid_outputs.roll - pid_outputs.yaw_rate);
	float pwm4 = (throttle - pid_outputs.pitch + pid_outputs.roll + pid_outputs.yaw_rate);

	/* Antes de igualarlo deberia delimitarlo a 1000 us 2000us */
	constrain(&pwm1,1000,2000);
	constrain(&pwm2,1000,2000);
	constrain(&pwm3,1000,2000);
	constrain(&pwm4,1000,2000);

	ccr->motor1_pwm =	(uint16_t) pwm1;
	ccr->motor2_pwm =	(uint16_t) pwm2;
	ccr->motor3_pwm =	(uint16_t) pwm3;
	ccr->motor4_pwm =	(uint16_t) pwm4;

	/* Aquí la función de mapear a los valores PWM */
}
