/*
 * uart.c
 *
 *  Created on: Jul 19, 2025
 *      Author: Hugo Roldan Lopez
 */
#include <stdint.h>
#include "const.h"
#include "stm32f411xe.h"
#include "util.h"
#include <string.h>

/* DMA ya tiene para configurar una circular queue  */

static void uart_set_baudrate(USART_TypeDef *USARTx, uint32_t PeriphClk, uint32_t BaudRate);
static void dma2_receiver_init(uint32_t src, uint32_t dst, uint32_t len);
static void dma2_transmitter_init(uint32_t dst);
static void dma2_uart1_init(void);


static  uint8_t *tx_buffer;
static volatile uint32_t tx_len;

static volatile uint8_t    dma_rx_buffer1[FRAME_LEN];
static volatile uint8_t    dma_rx_buffer2[FRAME_LEN];
static volatile uint8_t    dma_tx_buffer[TELEM_FRAME_LEN];
static volatile available_buf;

static volatile BaseType_t pxHigherPriorityTaskWoken;

extern TaskHandle_t RC_RX_ID, TELEM_ID;

static void uart_set_baudrate(USART_TypeDef *USARTx, uint32_t PeriphClk, uint32_t BaudRate)
{
	float usartdiv = (float)PeriphClk / (float)BaudRate;
	uint16_t mantissa = (uint16_t)usartdiv;
	uint8_t fraction = (uint8_t)((usartdiv - mantissa) * 16 + 0.5f);
	USARTx->BRR = (mantissa << 4) | (fraction & 0x0F);

}

static void dma2_uart1_init()
{
	/* Enable clock access to DMA2*/
	RCC->AHB1ENR |= RCC_AHB1ENR_DMA2EN;

    dma2_receiver_init((uint32_t)&USART1->DR,(uint32_t)dma_rx_buffer1, (uint32_t)dma_rx_buffer2,FRAME_LEN);
    dma2_transmitter_init((uint32_t)&USART1->DR);
}

static void dma2_receiver_init(uint32_t src, uint32_t dst1, uint32_t dst2, uint32_t len)
{
	/* Disable DMA2  Stream5 */
	DMA2_Stream5->CR &= ~DMA_SxCR_EN;

	/* Wait until DMA2 Stream 5 is disabled */
	while(DMA2_Stream5->CR & DMA_SxCR_EN);

	/* Clear all of interrupts flags of Stream5 */
	DMA2->HIFCR |= 0xF40;

	/* Set the source buffer (peripheral) */
	DMA2_Stream5->PAR = src;

	/* Set the destination buffer 1 (memory) */
	DMA2_Stream5->M0AR = dst1;

	/* Set the destination buffer 2 (memory) */
	DMA2_Stream5->M1AR = dst2;

	/* Set frame length */
	DMA2_Stream5->NDTR = len;

	/* Select channel 4 stream 5 */
	DMA2_Stream5->CR = (DMA2_Stream5->CR & ~DMA_SxCR_CHSEL) | (0x4 << DMA_SxCR_CHSEL_Pos);

	/* Enable memory increment */
	DMA2_Stream5->CR |= DMA_SxCR_MINC;

	/* Configure transfer direction (peripheral to memory)*/
	DMA2_Stream5->CR = (DMA2_Stream5->CR & ~DMA_SxCR_DIR) | (0x00 << DMA_SxCR_DIR_Pos);

	/* Enable double buffer and circular mode */
	DMA2_Stream5->CR |= DMA_SxCR_DBM | DMA_SxCR_CIRC;

	/* Enable direct mode and disable FIFO */
	DMA2_Stream5->FCR = 0;

	/* Enable DM2 stream 5*/
	DMA2_Stream5->CR |= DMA_SxCR_EN;

	/* Enable UART1 receiver DMA */
	USART1->CR3 |= USART_CR3_DMAR;

	/* DMA Interrupt enable in NVIC */
	NVIC_EnableIRQ(DMA2_Stream5_IRQn);
}

static void dma2_transmitter_init(uint32_t dst)
{
	/* Enable clock access to DMA*/
	RCC->AHB1ENR |= RCC_AHB1ENR_DMA2EN;

	/* Disable DMA2  Stream7 */
	DMA2_Stream7->CR &= ~DMA_SxCR_EN;

	/* Wait until DMA2 Stream 5 is disabled */
	while(DMA2_Stream7->CR & DMA_SxCR_EN);

	/* Set the destination buffer (peripheral) */
	DMA2_Stream7->PAR = dst;

	/* Select channel 4 stream 7 */
	DMA2_Stream7->CR = (DMA2_Stream5->CR & ~DMA_SxCR_CHSEL) | (0x4 << DMA_SxCR_CHSEL_Pos);

	/* Enable memory increment */
	DMA2_Stream7->CR |= DMA_SxCR_MINC;

	/* Configure transfer direction (memory to peripheral)*/
	DMA2_Stream7->CR = (DMA2_Stream5->CR & ~DMA_SxCR_DIR) | (0x01 << DMA_SxCR_DIR_Pos);

	/* Enable direct mode and disable FIFO */
	DMA2_Stream7->FCR = 0;

	/* Enable UART1 transmitter DMA */
	USART1->CR3 |= USART_CR3_DMAT;

	/* Enable DMA transfer complete interrupt */
	DMA2_Stream7->CR |= DMA_SxCR_TCIE;

	/* DMA Interrupt enable in NVIC */
	NVIC_EnableIRQ(DMA2_Stream7_IRQn);
}

/* El UART al cual conectamos ha de tener la misma configuración: 8N1 (8 bit, sin paridad, 1 stop bit) */
void uart1_txrx_init()
{
	/********Configure uart gpio pin********/

	/* Set PA9 pin to alternate function mode */
	GPIOA->MODER |= (1U<<19);
	GPIOA->MODER &= ~(1U<<18);

	/* Set PA10 pin to alternate function mode */
	GPIOA->MODER |= (1U<<21);
	GPIOA->MODER &= ~(1U<<20);

	/* Set PA9 alternate function type to UART_TX (AF07) */
	GPIOA->AFR[1] = (GPIOA->AFR[1] & ~GPIO_AFRH_AFSEL9) | (7 << GPIO_AFRH_AFSEL9_Pos);

	/* Set PA10 alternate function type to UART_RX (AF07) */
	GPIOA->AFR[1] = (GPIOA->AFR[1] & ~GPIO_AFRH_AFSEL10) | (7 << GPIO_AFRH_AFSEL10_Pos);

   /*********Configure uart module*********/

    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;	 					/* Enable clock access to USART1			 */
    uart_set_baudrate(USART1, APB2_CLK, BAUD);					/* Set baud rate		   	 				 */


    USART1->CR1 |= (USART_CR1_TE | USART_CR1_RE);							/* Enable USART1 transmitter and receiver	 */
    USART1->CR1 &= ~USART_CR1_M;											/* Set Word Length to 8 bit 	 			 */

    USART1->CR1 |= USART_CR1_UE;											/* USART enable 	*/

    dma2_uart1_init();
}

void uart1_send_dma(uint8_t *data, uint32_t len)
{
	/* Aqui normalmente habría que comprobar que no hay una transaccion DMA en curso, pero como se hacen cada 200 ms , seguro que ha acabado */
	/* Aquí el Stream7 está desactivado (se ha desactivado en la ISR y seguro que ha tenido tiempo de apagarse */

	/* Clear all of interrupts flags of Stream7 */
	DMA2->HIFCR |= 0xF400000;

	/* Set the source buffer (memory) */
	DMA2_Stream7->M0AR = (uint32_t)data;

	/* Set frame length */
	DMA2_Stream7->NDTR = len;

	/* Enable DMA2 Stream7 */
	DMA2_Stream7->CR |= DMA_SxCR_EN;
}

uint8_t uart1_read_dma(uint8_t* buf, uint16_t len)
{
	uint8_t  expected_cs = 0;
	uint16_t sum = 0;
	uint8_t *active_buf;

	/* Clear flag por si quedaba algo pendiente */
	DMA2->HIFCR |= DMA_HIFCR_CTCIF5;

	/* Enable DMA transfer complete interrupt, para que no salte la iSR cuando no nos interesa */
	DMA2_Stream5->CR |= DMA_SxCR_TCIE;

	/* We wait until DMA completes the transfer */
	xTaskNotifyWait(0,0,NULL,portMAX_DELAY);

	/* Comprobamos que buffer contiene los datos */
	*active_buf = (available_buf == 1) ? dma_rx_buffer1 : dma_rx_buffer2;

	/* El checksum se encuentra en el último byte */
	expected_cs = active_buf[FRAME_LEN-1];

	/* Copiamos los datos al buffer */
	memcpy(buf, active_buf, FRAME_LEN-1);

	/* Calculamos el checksum recibido */
	for(uint16_t i=0;i<len;i++) sum += buf[i];

	/* Nos quedamos con 1 byte */
	sum &= 0xFF;

	/* Si el checksum calculado coincide con el enviado por el esperado, copiamos la info al bufer */
	if(expected_cs == sum) return 1;
	else 				   return 0;

}
/* 6 porque considero el start bit, pero si alfinal hago esto de DMA modo circular + Circular Queue alomejor no lo usaré */

/* Trabajamos con doble buffer por temas de concurrencia, mientras copiamos el vector obtenido, el DMA podría modificar la variable */
/* El doble buffer nos da algo más de tiempo de margen para copiar los datos de forma segura */
/* Además, como las tramas son de solo 5 bytes, podemos copiar el vector en la misma ISR sin problema y sin generar latencia en el sistema */

static void DMA2_Stream5_callback()
{
	/* Deshabilitamos la interrupción por transferencia completada, uart_buf queda por tanto asegurado*/
	DMA2_Stream5->CR &= ~DMA_SxCR_TCIE;

	/* El bit CT nos indica a que buffer ha cambiado el hardware tras completarse la transacción, por tanto, el buffer donde tenemos datos es el opuesto al que nos indica este bit */
	if(DMA2_Stream5->CR & DMA_SxCR_CT)		available_buf = 1; /* Segundo buffer disponible */
	else									available_buf = 2; /* Primer buffer disponible  */

	/* Comprobamos que no hayamos despertado una tarea más prioritaria que la actual y cedemos CPU en caso afirmativo */
	pxHigherPriorityTaskWoken = pdFALSE;
	xTaskNotifyFromISR(RC_RX_ID,NULL,eNoAction,&pxHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
}

/* Creo que este callback no nos hace falta */
static void DMA2_Stream7_callback()
{
	/* Disable DMA2  Stream7 */
	// Desactivamos en la ISR, como entre llamadas a send_telemtry pasa mucho tiempo (100 ms) seguro que al hw le habrá dado tiempo a desactivarlo
	// De esta forma nos ahorramos ese while esperando a que el HW apague el DMA
	DMA2_Stream7->CR &= ~DMA_SxCR_EN;
}

// Acúerdate de ponerle la prioridad alta
void DMA2_Stream5_IRQHandler(void)
{
	/* Check for transfer complete interrupt */
	if(DMA2->HISR & DMA_HISR_TCIF5)
	{
		/* Clear flag */
		DMA2->HIFCR |= DMA_HIFCR_CTCIF5;

		/* Do something */
		DMA2_Stream5_callback();
	}
}

// Prioridad más baja
void DMA2_Stream7_IRQHandler(void)
{
	/* Check for transfer complete interrupt */
	if(DMA2->HISR & DMA_HISR_TCIF7)
	{
		/* Clear flag */
		DMA2->HIFCR |= DMA_HIFCR_CTCIF7;

		/* Do something */
		DMA2_Stream7_callback();
	}
}








