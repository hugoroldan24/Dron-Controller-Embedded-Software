/*
 * pid_control.c
 *
 *  Created on: Aug 1, 2025
 *      Author: 34684
 */

#include "stm32f411xe.h"
#include "const.h"
#include "stdint.h"
#include "util.h"
#include "dron_structs.h"



__STATIC_INLINE void normalize_error(float* error);

/* Normalize error to (-180,180] , avoid wrapping */
__STATIC_INLINE void normalize_error(float* error)
{
	if(*error>180.0f) 			*error -= 360.0f;
	else if(*error<=-180.0f) 	*error += 360.0f;
}

/* Obtenemos el error que el algoritmo PID deberá corregir */
void computePIDError(Setpoint_t setpoint, Attitude_t measure, Attitude_t* error)
{
	error->pitch = setpoint.pitch - measure.pitch;
	error->roll = setpoint.roll - measure.roll;
	error->yaw_rate = setpoint.yaw_rate - measure.yaw_rate;

	normalize_error(&error->pitch);
	normalize_error(&error->roll);

}

/* You execute this function for every movement */

float compute_PID(float error, float dt, PID_Controller_t* pid_params)
{
	float proportional = pid_params->kp * error;

	pid_params->integral += error * dt;
	float integral = pid_params->ki * pid_params->integral;

	float derivative = pid_params->kd * (error - pid_params->prev_error) / dt;

	pid_params->prev_error = error;

    float output = proportional + integral + derivative;

    /* Mantenemos la salida entre max y min */
    /* Piensa que output es literalmente el pulso que hay que generar para quitar el error , por tanto tu sabes que los ESC solo aceptan pulsos entre 1000 y 2000 */
    constrain(&output, pid_params->output_min, pid_params->output_max);

    return output;

}



