/*
 * FC_tasks.c
 *
 *  Created on: Sep 3, 2025
 *      Author: 34684
 */


#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "dron_structs.h"
#include "const.h"

#include "drivers.h"

#include "motor_mixer.h"
#include "pid_control.h"
#include "filter.h"
#include "telemetry.h"
#include "failsafe.h"
#include "joystick_mapper.h"
#include "util.h"


static void xHandleRCRxTask		 (void* parameters);
static void xHandleIMUTask	     (void* parameters);
static void xHandleControlTask	 (void* parameters);
static void xHandleSensorsTask	 (void* parameters);
static void xHandleTelemetryTask (void* parameters);
static void xHandleSafetyTask	 (void* parameters);

TaskHandle_t RC_RX_ID, IMU_ID, CTRL_ID, SENSORS_ID, TELEM_ID, SAFETY_ID, PID_ERROR_ID;
PWM_Outputs_t ccr;

/* Las declaramos como globales para poder calcular el error en otro hilo */
static Setpoint_t 	  desired_sp;
static Attitude_t	  measure;

typedef struct{
	int32_t  preassure;
	uint16_t battery_level;
}Telemetry_t;

QueueHandle_t telem_queue;
QueueHandle_t flight_data_queue;
QueueHandle_t pid_error_queue;

void Periph_Init()
{
	__disable_irq();
	I2C1_Init();
	SPI_Init();
	uart1_txrx_init();
	init_delay_timer();
	init_adc();

	pwm_init();
	dt_timer_init();

	__enable_irq();
	init_mpu6050();
	init_ms5611();
}

void createTasks()
{
	BaseType_t status;

	status = xTaskCreate(xHandleRCRxTask,"RC_RX",200,NULL,2,&RC_RX_ID); /* Task 1 */
	configASSERT(status == pdPASS); /* Esto es solo para quedarnos atrapados en un bucle si no se genera bien la tarea */

	status = xTaskCreate(xHandleIMUTask,"IMU",200,NULL,2,&IMU_ID);
	configASSERT(status == pdPASS);

	status = xTaskCreate(xHandleControlTask,"CTRL",200,NULL,5,&CTRL_ID);
	configASSERT(status == pdPASS);

	status = xTaskCreate(xHandleSensorsTask,"SENSORS",200,NULL,1,&SENSORS_ID);
	configASSERT(status == pdPASS);

	status = xTaskCreate(xHandleTelemetryTask,"TELEM",200,NULL,0,&TELEM_ID);
	configASSERT(status == pdPASS);

	status = xTaskCreate(xHandleSafetyTask,"SAFETY",200,NULL,4,&SAFETY_ID);
	configASSERT(status == pdPASS);

	status = xTaskCreate(xHandlePIDErrorTask,"ERROR",200,NULL,3,&PID_ERROR_ID);
	configASSERT(status == pdPASS);

	telem_queue = xQueueCreate(6,sizeof(Telemetry_t)); // Creamos una cola de 6 elementos del tamaño del struct 6 por si acaso se metieran más
	configASSERT(telem_queue != NULL);

	flight_data_queue = xQueueCreate(6,sizeof(FlightMessage_t));
	configASSERT(flight_data_queue != NULL);

	pid_error_queue = xQueueCreate(10,sizeof(FlightMessage_t));
	configASSERT(pid_error_queue != NULL);
}

/* Es importante tener controlado lo que tardamos, he de conseguir un sistema que trabaje a 4 ms */


static void xHandleRCRxTask(void* parameters)
{
	UserControl_t joystick_data;
	FlightMessage_t setpoint;
	setpoint.type = SETPOINT;

	while(1)
	{
		ulTaskNotifyTake(pdTRUE,portMAX_DELAY);

		get_joystick_data(&joystick_data);
		map_joystick_to_setpoint(joystick_data, &setpoint); // Obtenemos los ángulos del usuario

		/* Nos esperamos a que haya hueco para depositar el valor */
		/* Esta cola está compartida por otro hilo, internamente se hace exclusión mutua, pero igualmente habrá que controlar el orden con el que se escribe */
		xQueueSend(flight_data_queue,(void *)&setpoint,portMAX_DELAY);
		/* Este delay es para darle CPU a otras tareas menos prioritarias. Ojo porque una puede empezar el delay , la otra no y que cuando acaben las dos, a una le quede poco para despertar y la telemetria no tenga CPU */

		xTaskNotifyGive(IMU_ID);

		vTaskDelay(pdMS_TO_TICKS(1));
	}
}

static void xHandleIMUTask(void* parameters)
{
	float imu_data[6];
	FlightMessage_t imu_attitude;
	imu_attitude.type = IMU;
	imu_attitude.throttle = NULL; // No usamos throttle para IMU

	uint32_t lastcall = get_time_now_us();

	while(1)
	{
		mpu_read_acc_gyr(imu_data);
		computeAttitudeFromIMU(imu_data, &imu_attitude->attitude,&lastcall); // Obtenemos los ángulos del IMU

		xQueueSend(flight_data_queue,(void *)&imu_attitude,portMAX_DELAY);

		xTaskNotifyGive(RC_RX_ID);
		ulTaskNotifyTake(pdTRUE,portMAX_DELAY);

		vTaskDelay(pdMS_TO_TICKS(1));
	}
}

static void xHandlePIDErrorTask(void* parameters)
{
	FlightMessage_t rx_setpoint, rx_imu, pid_error;

	while(1){
		/* Asumimos que primero recibimos info de la IMU */
		xQueueReceive(flight_data_queue, &rx_imu, portMAX_DELAY);
		xQueueReceive(flight_data_queue, &rx_setpoint, portMAX_DELAY);

		// We do that so that the Control task can acces to the throttle
		pid_error.throttle = rx_setpoint.throttle;

		computePIDError(rx_setpoint.attitude, rx_imu.attitude, &pid_error->attitude);

		xQueueSend(pid_error_queue, ( void * )&pid_error,portMAX_DELAY);

	}
}

static void xHandleControlTask(void* parameters)
{
	FlightMessage_t 	  pid_error;

	PID_Controller_t roll_pid_params, pitch_pid_params, yaw_pid_params;

	/* Aquí habría que inicializar los PID parámetros */

	PID_Outputs_t output;

	uint32_t lastcall = 0;

	float dt;

	start_PWM();

	lastcall = get_time_now_us(); //Esto nos da el tiempo transcurrido desde que arrancamos el timer 2 */

	while(1)
	{
		xQueueReceive(pid_error_queue,&pid_error,portMAX_DELAY);

		dt = get_time_elapsed(&lastcall);

		output.roll 	= compute_PID(pid_error.attitude.roll, dt, &roll_pid_params);
		output.pitch 	= compute_PID(pid_error.attitude.pitch, dt, &pitch_pid_params);
		output.yaw_rate = compute_PID(pid_error.attitude.yaw_rate, dt, &yaw_pid_params);

		motor_mixer(output,pid_error.throttle,&ccr); /* Hay que asegurarse que en menos de 4 ms, ccr está actualizado */
	}
}

static void xHandleSensorsTask(void* parameters)
{

	Telemetry_t data;

	TickType_t xLastWakeTime;
    const TickType_t xFrequency = pdMS_TO_TICKS(200);
    xLastWakeTime = xTaskGetTickCount();

	while(1)
	{
		data.preassure     = read_preassure();
		data.battery_level = read_battery();
		xQueueSend(telem_queue, (void *)&data,portMAX_DELAY); //Esperamos a que haya espacio (si no hay)
		vTaskDelayUntil(&xLastWakeTime,xFrequency); /* Despertamos la tarea cada 200 ms */
	}
}
/* Si ponemos la telemetria más prioritaria, nos aseguramos que se ejecutará SIEMPRE antes que la lectura de sensores
 * por tanto nos pondremos a dormir ANTES de que los sensores notifiquen que estan listos
 */

/* Considerar el uso de Queues para pasar los datos */
static void xHandleTelemetryTask(void* parameters)
{

	Telemetry_t received_data;
	while(1)
	{
		xQueueReceive(telem_queue, &received_data,portMAX_DELAY); // Esperamos a que haya algo en la cola
		send_telemetry(battery_level, preassure);
	}
}

static void xHandleSafetyTask(void* parameters)
{
	// Bloquear nada más entrar, esta solo se notificará cuando la bateria sea muy baja o se pierda conexión,
	// Aqui se puede usar el notification value para ver que he activado
	while(1)
	{
		// Completar
	}
}
