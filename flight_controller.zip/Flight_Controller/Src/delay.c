/*
 * delay.c
 *
 *  Created on: Jul 26, 2025
 *      Author: 34684
 */
#include "stm32f411xe.h"

#include <stdint.h>
#include "const.h"

/* El INLINE es para que la función se inserte directamente donde se ponga y no se haga una llamada a esa función, para ahorrar ciclos */
/* Esto es para que el compilador, cuando llamemos a una funcion de delay, en vez de SALTAR a otra zona de memoria para ejecutar la función, siga el flujo normal de ejecución sin saltos
__STATIC_INLINE void _delay_ticks(uint32_t ticks); */

static volatile uint8_t flag;

void init_delay_timer()
{
	/* Clock acces to Timer 5 */
	RCC->APB1ENR |= RCC_APB1ENR_TIM5EN;

	/* Set Prescaler, since the prescaler for APB1 bus is 2, the timer clock is twice the bus freq. so it is 100 MHz */
	TIM5->PSC = 2*APB1_CLK_MHZ - 1;  // 100 MHz / (99 +1) = 1 MHz -> 1 tick = 1us

	/* Upcounting */
	TIM5->CR1 &= ~TIM_CR1_DIR;

	/* Set buffered ARR */
	TIM5->CR1 |= TIM_CR1_ARPE;

	/* Set One Pulse Mode, so that when reaching ARR, we stop counting */
	TIM5->CR1 |= TIM_CR1_OPM;

	/* Set URS so that only counter overflow triggers interrupt ( so that when we do a reset setting UG bit, we don't trigger any interrupt */
	TIM5->CR1 |= TIM_CR1_URS;

	TIM5->CNT = 0;

	/* Clear pending interrupt just in case */
	TIM5->SR &= ~TIM_SR_UIF;

	/* Enable event interrupt */
	TIM5->DIER |= TIM_DIER_UIE;

	NVIC_EnableIRQ(TIM5_IRQn);    // Activa la interrupción de TIM5 en el NVIC
}

__STATIC_INLINE void _delay_ticks(uint32_t ticks)
{
	flag = 0;

	/* Set autoreload value */
	TIM5->ARR = ticks - 1;

	/* Force the update from ARR (we restart the counter from 0) Wont trigger interrupt*/
	TIM5->EGR |= TIM_EGR_UG;

    /* Start counting */
	TIM5->CR1 |= TIM_CR1_CEN;

	while(!flag);
}

void delay_ms(uint32_t ms){ _delay_ticks(1000*ms);}
void delay_us(uint32_t us){ _delay_ticks(us);}

void TIM5_IRQHandler()
{
	if (TIM5->SR & TIM_SR_UIF)
	{
		TIM5->SR &= ~TIM_SR_UIF;
		flag =  1;
	}

}


